import { Component,Input, EventEmitter, Output } from '@angular/core';
import { CustomerDetailsService } from '../customer-details.service';
import{Details} from '../details';




export type user ={
  id:number;
  name:string;
  description:string;

}
@Component({
  selector: 'app-order-details',
  templateUrl: './order-details.component.html',
  styleUrls: ['./order-details.component.css']
})
export class OrderDetailsComponent  {
  public customer:user={id:1,name:'',description:''};
public heading: string ="";

@Output() sendData = new EventEmitter;
  constructor(private custDetails:CustomerDetailsService) { }
 

  ngOnInit(): void {
  }

order(){
this.sendData.emit(this.customer);

this.custDetails.addUser(this.customer);
}
}
