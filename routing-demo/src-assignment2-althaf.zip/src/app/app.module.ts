import { NgModule } from '@angular/core';
import { BrowserModule } from '@angular/platform-browser';

import { AppRoutingModule } from './app-routing.module';
import { AppComponent } from './app.component';
import { HomeComponent } from './home/home.component';
import { OrderComponent } from './order/order.component';
import { ProductsComponent } from './products/products.component';
import { OrderDetailsComponent } from './order-details/order-details.component';
import { FormsModule } from '@angular/forms';
import { CustomerDetailsService } from './customer-details.service';


@NgModule({
  declarations: [
    AppComponent,
    HomeComponent,
    OrderComponent,
    ProductsComponent,
    OrderDetailsComponent,
    
    
    
  ],
  imports: [
    BrowserModule,
    AppRoutingModule,
    FormsModule
  ],
  providers: [CustomerDetailsService],
  bootstrap: [AppComponent]
})
export class AppModule { }
