import { Component, Input, OnInit, OnChanges,OnDestroy, SimpleChanges } from '@angular/core';
 import {details} from '../details';

@Component({
  selector: 'app-order',
  templateUrl: './order.component.html',
  styleUrls: ['./order.component.css']
})
export class OrderComponent implements OnInit {
@Input() heading:string;
@Input()details:details;

  constructor() { }

ngonDestroy():void{
console.log("child destroyed")

}
ngonChanges(changes:SimpleChanges):void{
  debugger
  console.log(changes)
}
  ngOnInit(): void {
  }

}
