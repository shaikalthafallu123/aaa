export class Details{
    id:number;
    name:string;
    description:string;
}