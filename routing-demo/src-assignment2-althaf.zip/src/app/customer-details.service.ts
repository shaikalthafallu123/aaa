import { Injectable } from '@angular/core';



export type customer={
  id:number;
  name:string;
  description:string;
};


@Injectable({
  providedIn: 'root'
})
export class CustomerDetailsService {
public customer:customer[]=[{id:1,name:'',description:''}];
public addUser(user:any){
  this.customer.push({...user});
}
  constructor() { }

}
