import { Component, OnInit,ElementRef } from '@angular/core';

@Component({
  selector: 'app-child',
  templateUrl: './child.component.html',
  styleUrls: ['./child.component.css']
})
export class ChildComponent implements OnInit {
 
  public num:number=0;
  public boolean=true
  constructor() { }

  ngOnInit(): void {
  }

}
