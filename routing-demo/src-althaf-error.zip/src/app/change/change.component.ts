import { Component,Input,OnChanges,OnDestroy,OnInit,SimpleChanges } from '@angular/core';
import{Details} from '../details';

@Component({
  selector: 'app-change',
  templateUrl: './change.component.html',
  styleUrls: ['./change.component.css']
})
export class ChangeComponent implements OnInit,OnChanges,OnDestroy {
@Input() heading:string;
@Input() details:Details;

  constructor() { }
  ngOnDestroy(): void {
    throw new Error('Method not implemented.');
  }
  ngOnChanges(changes: SimpleChanges): void {
    throw new Error('Method not implemented.');
  }
  ngonDestroy():void {
    console.log("child destroyed")
  }

  ngonchanges(changes:SimpleChanges):void{
debugger
console.log(changes);
  }

  ngOnInit(): void {
  }

}
