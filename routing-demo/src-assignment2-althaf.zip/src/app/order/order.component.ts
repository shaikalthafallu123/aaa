import { Component, Input, OnInit,  SimpleChanges } from '@angular/core';
import * as EventEmitter from 'events';
import { Details } from '../details';


@Component({
  selector: 'app-order',
  templateUrl: './order.component.html',
  styleUrls: ['./order.component.css']
})
export class OrderComponent implements OnInit {
@Input() heading:string;
@Input() details:Details;
public Title:any;

  constructor() { }
 ngOnInit(): void {
  }

  receiveData(data:any){
 this.Title=data

  }
}
