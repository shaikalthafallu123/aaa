import { Component, OnInit } from '@angular/core';
import {Details} from '../details';

@Component({
  selector: 'app-order-details',
  templateUrl: './order-details.component.html',
  styleUrls: ['./order-details.component.css']
})
export class OrderDetailsComponent implements OnInit {
heading:string;
id:number;
name:string;
description:string;
details:Details=new Details;
z
  constructor() { }

  ngOnInit(): void {
  }

  order(){
    this.details=new Details;
     this.details.id=this.id;
     this.details.name=this.name;
     this.details.description=this.description;
  }
}
